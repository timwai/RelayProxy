import test from 'node:test';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import { getOrCreateIdentity } from '../src/device-identity.js';
import { encryptSnapshot, decryptSnapshot, signedHeader } from '../src/session-envelope.js';
import { captureCookies, applyCookies } from '../src/cookies.js';

globalThis.crypto ||= webcrypto;

// A fake Chrome Profile with persistent, non-exportable CryptoKey storage,
// mutable Cookie store, and no actual OS Chrome requirement.
function createProfile() {
  const privateKeys = new Map();
  const local = new Map();
  const jar = new Map();
  const database = {
    createObjectStore() {},
    transaction(){
      let active=0;
      const tx={objectStore(){return {
        get(name){return request(()=>privateKeys.get(name));},
        put(value,name){return request(()=>privateKeys.set(name,value));},
        delete(name){return request(()=>privateKeys.delete(name));}
      }}};
      function request(run){
        const q={};active++;
        queueMicrotask(()=>{
          try{q.result=run();q.onsuccess?.();}
          catch(error){q.error=error;q.onerror?.();}
          finally{active--;queueMicrotask(()=>{if(active===0)tx.oncomplete?.()});}
        });
        return q;
      }
      return tx;
    },
    close() {}
  };
  return {
    jar,
    indexedDB: {open() {
      const req = {result: database};
      queueMicrotask(() => {req.onupgradeneeded?.();req.onsuccess?.();});
      return req;
    }},
    chrome: {
      storage: {local: {
        async get(key) {return {[key]:local.get(key)};},
        async set(obj) {for(const [k,v] of Object.entries(obj))local.set(k,v);}
      }},
      cookies: {
        async getAll({url}) {
          const host=new URL(url).hostname;
          return [...jar.values()].filter(c=>
            host===c.domain.replace(/^\./,'')||
            (!c.hostOnly&&host.endsWith('.'+c.domain.replace(/^\./,''))));
        },
        async remove({url,name}) {
          if (new URL(url).hostname!=='example.com'||!jar.has(name)) return null;
          jar.delete(name);
          return {url,name};
        },
        async set(details) {
          const c = {
            name:details.name,value:details.value,secure:details.secure,
            httpOnly:details.httpOnly,sameSite:details.sameSite||'unspecified',
            hostOnly:true,path:'/',domain:new URL(details.url).hostname,
            ...(details.expirationDate?{expirationDate:details.expirationDate}:{}),
          };
          jar.set(c.name,c);return c;
        }
      }
    }
  };
}
function use(profile) {
  globalThis.chrome = profile.chrome;
  globalThis.indexedDB = profile.indexedDB;
}
const policy={siteOrigin:'https://example.com',cookieNames:['session']};
const sessionValue='super-high-entropy-session-test-value';

test('two Chrome profiles encrypt/decrypt a signed session envelope and block tampering', async()=>{
  const source = createProfile(), target = createProfile();
  use(source);
  const a = await getOrCreateIdentity();
  use(target);
  const b = await getOrCreateIdentity();
  const rule = {ruleId:crypto.randomUUID(),status:'active',
    sourceBrowserDeviceId:a.deviceId,targetBrowserDeviceId:b.deviceId};
  const cookie = {name:'session',value:sessionValue,secure:true,httpOnly:true,
    sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'};
  source.jar.set('session',cookie);
  use(source);
  const payload=await captureCookies(policy);
  const encrypted=await encryptSnapshot(rule,{...b,id:b.deviceId},1,payload);
  assert.equal(encrypted.type,'SESSION_SNAPSHOT');
  assert.equal(encrypted.encryption.suite,'P256-HKDF-SHA256-A256GCM-v1');
  assert.equal(encrypted.ciphertext.includes(sessionValue),false);
  assert.equal(signedHeader(encrypted).includes('example.com'),false);
  use(target);
  const clear=await decryptSnapshot(encrypted,{...a,id:a.deviceId});
  assert.deepEqual(clear,payload);
  const result=await applyCookies(rule.ruleId,clear,policy);
  assert.equal(result.status,'APPLIED');
  assert.equal(target.jar.get('session').value,sessionValue);
  const corrupted={...encrypted,ciphertext:(encrypted.ciphertext[0]==='A'?'B':'A')+encrypted.ciphertext.slice(1)};
  await assert.rejects(decryptSnapshot(corrupted,{...a,id:a.deviceId}),/签名/);
});

test('receiver request token is covered by source ECDSA signature and AES-GCM',async()=>{
  const source=createProfile(),target=createProfile();
  use(source);
  const a=await getOrCreateIdentity();
  use(target);
  const b=await getOrCreateIdentity();
  const rule={ruleId:crypto.randomUUID(),status:'active',
    sourceBrowserDeviceId:a.deviceId,targetBrowserDeviceId:b.deviceId};
  const payload={siteOrigin:policy.siteOrigin,cookies:[],removedNames:[],cookieNames:[]};
  const requestId=crypto.randomUUID();
  use(source);
  const encrypted=await encryptSnapshot(rule,{...b,id:b.deviceId},1,payload,requestId);
  assert.equal(encrypted.transferRequestId,requestId);
  assert.ok(signedHeader(encrypted).endsWith(requestId));
  use(target);
  assert.deepEqual(await decryptSnapshot(encrypted,{...a,id:a.deviceId}),payload);
  const swapped={...encrypted,transferRequestId:crypto.randomUUID()};
  await assert.rejects(decryptSnapshot(swapped,{...a,id:a.deviceId}),/签名/);
  const missing={...encrypted};
  delete missing.transferRequestId;
  await assert.rejects(decryptSnapshot(missing,{...a,id:a.deviceId}),/签名/);
  const forged={...encrypted,transferRequestId:'not-a-uuid'};
  await assert.rejects(decryptSnapshot(forged,{...a,id:a.deviceId}),/请求 ID/);
});

test('host-only root and existing-login conflicts are enforced without token storage',async()=>{
  const p=createProfile();use(p);
  const conflicting={name:'session',value:'existing-browser-account',secure:true,
    httpOnly:true,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'};
  p.jar.set('session',conflicting);
  const snapshot={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[{name:'session',value:'remote-different-account',secure:true,httpOnly:true,sameSite:'lax'}],removedNames:[]};
  await assert.rejects(applyCookies('rule',snapshot,policy),/CONFLICT/);
  assert.equal(p.jar.get('session').value,'existing-browser-account');
  await applyCookies('rule',snapshot,policy,{allowOverwrite:true});
  assert.equal(p.jar.get('session').value,'remote-different-account');
  p.jar.get('session').value='modified-on-target';
  await assert.rejects(applyCookies('rule',{...snapshot,cookies:[{...snapshot.cookies[0],value:'next-from-source'}]},policy),/CONFLICT/);
  p.jar.set('session',{...conflicting,hostOnly:false,domain:'.example.com'});
  await assert.rejects(captureCookies(policy),/作用域/);
});

test('logout removes only Cookie values last installed by the same rule', async () => {
  const source=createProfile(),target=createProfile();
  use(source);
  source.jar.set('session',{name:'session',value:'account-on-A',secure:true,
    httpOnly:true,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'});
  const loggedIn=await captureCookies(policy);
  use(target);
  await applyCookies('logout-rule',loggedIn,policy);
  assert.equal(target.jar.get('session').value,'account-on-A');

  use(source);
  source.jar.delete('session');
  const loggedOut=await captureCookies(policy);
  assert.deepEqual(loggedOut.removedNames,['session']);
  assert.deepEqual(loggedOut.cookies,[]);
  use(target);
  const removed=await applyCookies('logout-rule',loggedOut,policy);
  assert.equal(removed.removed,1);
  assert.equal(target.jar.has('session'),false);

  target.jar.set('session',{name:'session',value:'other-local-account',secure:true,
    httpOnly:true,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'});
  await assert.rejects(applyCookies('logout-rule',loggedOut,policy),/CONFLICT/);
  assert.equal(target.jar.get('session').value,'other-local-account');
});

test('same-value Cookie from an independent login is never adopted for logout', async()=>{
  const target=createProfile();use(target);
  target.jar.set('session',{name:'session',value:'same-cookie-as-source',
    secure:true,httpOnly:true,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'});
  const original={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[{name:'session',value:'same-cookie-as-source',secure:true,
      httpOnly:true,sameSite:'lax'}],removedNames:[]};
  await applyCookies('not-owned',original,policy);
  await assert.rejects(applyCookies('not-owned',{siteOrigin:policy.siteOrigin,
    cookieNames:policy.cookieNames,cookies:[],removedNames:['session']},policy),/CONFLICT/);
  assert.equal(target.jar.get('session').value,'same-cookie-as-source');
});

test('logout refuses deleting a Cookie modified by the receiver after sync',async()=>{
  const target=createProfile();use(target);
  const initially={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[{name:'session',value:'initial-source-cookie',secure:true,
      httpOnly:true,sameSite:'strict'}],removedNames:[]};
  await applyCookies('logout-protected',initially,policy);
  target.jar.get('session').value='changed-by-target-site';
  const removed={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[],removedNames:['session']};
  await assert.rejects(applyCookies('logout-protected',removed,policy),/CONFLICT/);
  assert.equal(target.jar.get('session').value,'changed-by-target-site');
  await assert.rejects(applyCookies('logout-protected',
    {...removed,removedNames:['session','unexpected']},policy));
});

test('partial multi-Cookie writes roll back without changing the existing account',async()=>{
  const target=createProfile();use(target);
  const policy2={siteOrigin:'https://example.com',cookieNames:['csrf','session']};
  const snapshot={siteOrigin:policy2.siteOrigin,cookieNames:policy2.cookieNames,
    cookies:[
      {name:'csrf',value:'new-csrf-value',secure:true,httpOnly:false,sameSite:'lax'},
      {name:'session',value:'new-session-value',secure:true,httpOnly:true,sameSite:'lax'},
    ],removedNames:[]};
  const originals=[
    {name:'csrf',value:'old-csrf',secure:true,httpOnly:false,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'},
    {name:'session',value:'old-session',secure:true,httpOnly:true,sameSite:'lax',hostOnly:true,domain:'example.com',path:'/'}
  ];
  for(const c of originals)target.jar.set(c.name,c);
  const set=target.chrome.cookies.set.bind(target.chrome.cookies);
  let attempts=0;
  target.chrome.cookies.set=async details=>{
    if(++attempts===2)throw new Error('injected cookie API failure');
    return set(details);
  };
  await assert.rejects(applyCookies('atomic-rollback',snapshot,policy2,{allowOverwrite:true}),/APPLY_FAILED/);
  assert.equal(target.jar.get('csrf').value,'old-csrf');
  assert.equal(target.jar.get('session').value,'old-session');
  // HMAC ownership markers must not be committed for incomplete snapshots.
  const record=await target.chrome.storage.local.get('browserSyncManagedCookieHmacV1');
  assert.equal(record.browserSyncManagedCookieHmacV1?.['atomic-rollback'],undefined);
});

test('partial failure deletes newly added Cookie rather than leaving a mixed login',async()=>{
  const target=createProfile();use(target);
  const policy2={siteOrigin:'https://example.com',cookieNames:['csrf','session']};
  const snapshot={siteOrigin:policy2.siteOrigin,cookieNames:policy2.cookieNames,
    cookies:[
      {name:'csrf',value:'brand-new-csrf',secure:true,httpOnly:false,sameSite:'lax'},
      {name:'session',value:'new-session',secure:true,httpOnly:true,sameSite:'lax'}
    ],removedNames:[]};
  const set=target.chrome.cookies.set.bind(target.chrome.cookies);
  target.chrome.cookies.set=async details=>{
    if(details.name==='session')throw new Error('injected failure');
    return set(details);
  };
  await assert.rejects(applyCookies('new-cookie-rollback',snapshot,policy2),/APPLY_FAILED/);
  assert.equal(target.jar.size,0);
});

test('incomplete rollback reports manual intervention rather than claiming success',async()=>{
  const target=createProfile();use(target);
  const policy2={siteOrigin:'https://example.com',cookieNames:['csrf','session']};
  const snapshot={siteOrigin:policy2.siteOrigin,cookieNames:policy2.cookieNames,
    cookies:[
      {name:'csrf',value:'changed-csrf',secure:true,httpOnly:false,sameSite:'lax'},
      {name:'session',value:'changed-session',secure:true,httpOnly:true,sameSite:'lax'}
    ],removedNames:[]};
  const set=target.chrome.cookies.set.bind(target.chrome.cookies);
  target.chrome.cookies.set=async details=>{
    if(details.name==='session'){
      target.jar.get('csrf').value='modified-by-website';
      throw new Error('injected failure and external update');
    }
    return set(details);
  };
  await assert.rejects(applyCookies('concurrent-update',snapshot,policy2),/PARTIAL_ROLLBACK/);
  assert.equal(target.jar.get('csrf').value,'modified-by-website');
});

test('orphaned restore journal blocks automatic writes after MV3 worker restart',async()=>{
  const p=createProfile();use(p);
  const partialRule='interrupted-restore';
  await p.chrome.storage.local.set({browserSyncRestoreJournal:{[partialRule]:{startedAt:Date.now()}}});
  const snapshot={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[{name:'session',value:'test-cookie',secure:true,httpOnly:true,sameSite:'lax'}],removedNames:[]};
  await assert.rejects(applyCookies(partialRule,snapshot,policy),/PARTIAL_ROLLBACK/);
  assert.equal(p.jar.size,0,'crash recovery guard changed the Cookie jar');
});

test('successful restore and clean rollback both clear in-progress journal',async()=>{
  const p=createProfile();use(p);
  const snapshot={siteOrigin:policy.siteOrigin,cookieNames:policy.cookieNames,
    cookies:[{name:'session',value:'first',secure:true,httpOnly:true,sameSite:'lax'}],removedNames:[]};
  await applyCookies('journal-success',snapshot,policy);
  let j=(await p.chrome.storage.local.get('browserSyncRestoreJournal')).browserSyncRestoreJournal;
  assert.equal(j['journal-success'],undefined);
  const setter=p.chrome.cookies.set.bind(p.chrome.cookies);
  p.chrome.cookies.set=async ()=>{throw new Error('test failure');};
  await assert.rejects(applyCookies('journal-failure',
    {...snapshot,cookies:[{...snapshot.cookies[0],value:'second'}]},policy,{allowOverwrite:true}),/APPLY_FAILED/);
  j=(await p.chrome.storage.local.get('browserSyncRestoreJournal')).browserSyncRestoreJournal;
  assert.equal(j['journal-failure'],undefined);
  assert.equal(p.jar.get('session').value,'first');
  p.chrome.cookies.set=setter;
});
