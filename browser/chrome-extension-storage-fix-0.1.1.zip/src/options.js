import { parseSiteOrigin, getSettings, updateSettings } from './rules.js';
import {cookieAccessOrigins} from './cookie-access.js';
import {diagnosticText,ruleTransferStatus,TRANSFER_STATUS_KEYS} from './sync-diagnostics.js';

const $ = id => document.getElementById(id);
const status = text => { $('message').textContent = text; $('message').className = ''; };
const failure = error => { $('message').textContent = String(error.message || error); $('message').className = 'error'; };
$('extension-version').textContent='扩展版本 '+chrome.runtime.getManifest().version;

function renderSites(sites) {
  const list = $('sites');
  list.replaceChildren();
  const siteSelect = $('pair-site');
  const prior = siteSelect.value;
  siteSelect.replaceChildren();
  for (const origin of sites) {
    const li = document.createElement('li');
    li.append(textNode('span',origin));
    const repair=document.createElement('button');
    repair.textContent='补全 Cookie 权限';
    repair.addEventListener('click',async()=>{
      try{
        const granted=await chrome.permissions.request({origins:cookieAccessOrigins(origin)});
        status(granted?'站点 Cookie 权限已补全，请重新请求同步。':'Cookie 权限未获授予。');
      }catch(error){failure(error);}
    });
    const remove=document.createElement('button');
    remove.textContent='移除授权';remove.title='停止该站点后续同步';
    remove.addEventListener('click',async()=>{
      try { await ask({type:'REMOVE_SITE',siteOrigin:origin});
        const latest=await getSettings();renderSites(latest.sites);
        status('已撤销站点同步授权；原网站登录状态未清除。');
      }catch(error){failure(error);}
    });
    li.append(repair,remove);list.append(li);
    const option = document.createElement('option');
    option.value = origin;
    option.textContent = origin;
    siteSelect.append(option);
  }
  if (sites.includes(prior)) siteSelect.value = prior;
}

async function refreshSiteChoices(){
  const select=$('site'),selected=select.value;
  const tabs=await chrome.tabs.query({});
  const sites=[...new Set(tabs.map(tab=>{
    try {
      const u=new URL(tab.url);
      return ['http:','https:'].includes(u.protocol) ? u.origin : null;
    }catch{return null;}
  }).filter(Boolean))].sort();
  select.replaceChildren();
  const prompt=document.createElement('option');
  prompt.value='';
  prompt.textContent=sites.length?'请选择已打开的网站':'请先在 Chrome 打开 HTTP/HTTPS 网站';
  select.append(prompt);
  for(const site of sites){
    const item=document.createElement('option');
    item.value=site;item.textContent=site.startsWith('http://')?'HTTP（不安全） · '+site:site;
    select.append(item);
  }
  if(sites.includes(selected))select.value=selected;
}
$('refresh-sites').addEventListener('click',()=>refreshSiteChoices().catch(failure));

async function load() {
  const result = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
  if (!result?.ok) throw new Error(result?.error || 'Extension background unavailable');
  $('device').textContent = result.identity.deviceId;
  const retrying=!result.connected&&result.nextRetryAt>Date.now();
  $('server-stage').textContent = result.connected ? '设备认证已连接' :
    result.pendingApproval ? '等待管理员审批，批准后自动连接' :
    retrying ? '连接中断，等待自动重连（约 '+Math.ceil((result.nextRetryAt-Date.now())/1000)+' 秒）' :
    result.settings.serverOrigin ? '尚未连接 Server' : '尚未配置 Server';
  $('server').value = result.settings.serverOrigin;
  $('identity-id').value = result.settings.requestedIdentityId || '';
  $('device-name').value = result.settings.deviceName || '';
  renderSites(result.settings.sites);
  await refreshSiteChoices();
  $('local-agent-all').checked=!!result.localAgentProxy?.enabled;
  $('local-agent-port').value=result.localAgentProxy?.port||21291;
}

$('local-agent-apply').addEventListener('click',async()=>{
  try{
    const enabled=$('local-agent-all').checked;
    const port=Number($('local-agent-port').value);
    await ask({type:'SET_LOCAL_AGENT_GLOBAL',enabled,port});
    status(enabled?'Chrome 浏览器代理已交给本机 RelayProxy Agent 的原生分流':'已停用本机 Agent 全浏览器代理，保留独立会话网络规则');
  }catch(error){failure(error);}
});

$('add-site').addEventListener('click', async () => {
  try {
    const origin = parseSiteOrigin($('site').value.trim());
    // An explicit secondary warning prevents accidental HTTP credential
    // disclosure; the site's own traffic cannot be secured by E2EE sync.
    if(origin.startsWith('http://') && !window.confirm(
      '此网站使用 HTTP：网站登录 Cookie 和 Storage 可能在网络中被窃取或篡改。' +
      'RelayProxy 只加密设备间的同步数据，无法加密您与网站之间的 HTTP 连接。仍要授权此站点吗？'))return;
    // Call request() directly from a user click; never grant silently.
    const granted = await chrome.permissions.request({origins:cookieAccessOrigins(origin)});
    if (!granted) return status('站点权限未获授予。');
    const settings = await getSettings();
    if (!settings.sites.includes(origin)) {
      settings.sites.push(origin);
      await updateSettings({ sites: settings.sites });
    }
    renderSites(settings.sites);
    status(origin.startsWith('http://')?'HTTP 站点已授权（网站访问仍为明文）；尚未建立配对。':'站点权限已授予。尚未启用会话传输。');
  } catch (error) { failure(error); }
});

$('connect').addEventListener('click', async () => {
  const button=$('connect');
  try{
    const raw=$('server').value.trim();
    const origin=new URL(raw);
    if(origin.protocol!=='https:'||origin.pathname!=='/'||
       origin.search||origin.hash||origin.username||origin.password)
      throw new Error('仅支持 HTTPS Server Origin');
    const requestedIdentityId=$('identity-id').value.trim();
    const deviceName=$('device-name').value.trim();
    if(!requestedIdentityId){
      $('identity-id').focus();
      throw new Error('身份 ID 为必填项');
    }
    if(!deviceName){
      $('device-name').focus();
      throw new Error('设备名称为必填项');
    }
    if(deviceName.length>100||requestedIdentityId.length>128)
      throw new Error('身份 ID 或设备名称过长');
    // Chrome host permission must be requested directly in the click path.
    const allowed=await chrome.permissions.request({
      origins:[origin.protocol+'//'+origin.hostname+'/*']
    });
    if(!allowed)throw new Error('未授予 Server 访问权限');
    button.disabled=true;
    const current=await getSettings();
    if(current.serverOrigin!==origin.origin)
      await ask({type:'SAVE_SERVER',serverOrigin:origin.origin});
    await updateSettings({requestedIdentityId,deviceName});
    const registered=await ask({type:'REGISTER_BROWSER'});
    if(registered.state!=='approved'){
      $('server-stage').textContent=registered.state==='pending'?'等待管理员审批':'设备授权未生效';
      status(registered.state==='pending'
        ?'设备授权申请已提交；管理员批准后扩展会自动连接，无须再次点击。'
        :'设备状态：'+registered.state+'；请在 Server Web 核对授权。');
      return;
    }
    await ask({type:'CONNECT_BROWSER'});
    $('server-stage').textContent='设备认证已连接';
    status('已连接服务端，设备身份认证通过。');
    await refreshPairing();
  }catch(error){failure(error);}
  finally{button.disabled=false;}
});

async function ask(message) {
  const result = await chrome.runtime.sendMessage(message);
  if (!result?.ok) throw new Error(result?.error || '浏览器配对请求失败');
  return result;
}

let cachedRules = [];
let cachedPeers = [];

async function refreshPairing() {
  const peers = (await ask({ type: 'LIST_PEERS' })).peers || [];
  cachedPeers=peers;
  const select = $('target');
  const previous = select.value;
  select.replaceChildren();
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = '请选择已审批的接收设备';
  select.append(placeholder);
  for (const peer of peers.filter(p => p.receive)) {
    const option = document.createElement('option');
    option.value = peer.id;
    option.textContent = (peer.name || 'Chrome') + ' · ' + peer.id.slice(0, 18);
    select.append(option);
  }
  if (peers.some(p => p.id === previous && p.receive)) select.value = previous;
  cachedRules = (await ask({ type: 'LIST_RULES' })).rules || [];
  renderRules(cachedRules,peers);
}

function textNode(tag, content, className) {
  const node = document.createElement(tag);
  node.textContent = content;
  if (className) node.className = className;
  return node;
}

function renderRules(rules,peers=[]) {
  const peerNames=new Map(peers.map(peer=>[peer.id,peer.name||'Chrome 浏览器']));
  const parent = $('pairing-rules');
  parent.replaceChildren();
  if (!rules.length) {
    parent.append(textNode('p', '暂无配对邀请。'));
    return;
  }
  for (const rule of rules) {
    const card = document.createElement('div');
    card.className = 'rule';
    const desc = rule.role === 'source' ? '发送端' : '接收端';
    card.append(textNode('strong', desc + ' · ' + ({active:'已启用',offered:'待确认',revoked:'已撤销'}[rule.status]||rule.status)));
    const peerName=peerNames.get(rule.remoteID)||'浏览器设备';
    const peerId=String(rule.remoteID||'');
    const peerLabel=textNode('p','配对设备：'+peerName+(peerId?' · '+peerId.slice(0,12)+'…':''));
    peerLabel.title=peerId;
    card.append(peerLabel);
    if (rule.lastTransfer && ['SENDING','RELAYED','RECEIVED','APPLIED','FAILED','CONFLICT','UNKNOWN','PARTIAL'].includes(rule.lastTransfer.state)) {
      const translated = {SENDING:'正在发送密文',RELAYED:'密文已转发',RECEIVED:'接收端已收到',
        APPLIED:'站点状态已应用（网站登录未验证）',FAILED:'同步失败',
        CONFLICT:'目标已有不同登录状态',UNKNOWN:'结果尚不确定，可重试或等待对账',
        PARTIAL:'浏览器状态恢复不完整，已暂停接收，必须人工检查'};
      card.append(textNode('p', '最近同步：' + translated[rule.lastTransfer.state]));
      const diagnostic=diagnosticText(rule.lastTransfer);
      if(diagnostic)card.append(textNode('p','失败详情：'+diagnostic,'error'));
    }
    if (!rule.valid) {
      card.append(textNode('p', rule.error || '尚未找到经核验的设备密钥，无法授权。', 'error'));
    } else {
      card.append(textNode('p', '站点：' + rule.policy.siteOrigin));
      if(rule.policy.siteOrigin.startsWith('http://'))
        card.append(textNode('p', 'HTTP 风险：网站访问与登录凭据可能明文暴露，设备间同步本身仍为加密传输。', 'error'));
      const selected=Array.isArray(rule.policy.cookieNames)
        ?'旧版指定 Cookie：'+rule.policy.cookieNames.join(', ')
        :['allCookies','localStorage','sessionStorage','indexedDB']
          .filter(key=>rule.policy[key]===true)
          .map(key=>({allCookies:'Cookie',localStorage:'Local Storage',
            sessionStorage:'Session Storage',indexedDB:'IndexedDB'}[key]))
          .join(' / ');
      card.append(textNode('p','同步范围：'+selected));
      if(rule.policy.localStorage||rule.policy.sessionStorage)
        card.append(textNode('p','Storage 使用本机最近激活的同站点标签页。同步前请先点击要使用的网站标签页；Session Storage 不会合并其他标签页。写入后保留当前页面，需要网站重新读取登录状态时请手动刷新。'));
      card.append(textNode('div', '配对校验码：' + rule.code, 'code'));
      if (rule.status === 'offered' &&
          ((rule.role === 'target' && !rule.targetApproved) ||
           (rule.role === 'source' && rule.targetApproved))) {
        const label = document.createElement('label');
        const checked = document.createElement('input');
        checked.type = 'checkbox';
        label.append(checked, textNode('span', '我已通过独立渠道与另一台设备核对上述校验码。'));
        card.append(label);
        const button = document.createElement('button');
        button.textContent = rule.role === 'target' ? '接受邀请' : '最终确认并激活';
        button.disabled = true;
        checked.addEventListener('change', () => { button.disabled = !checked.checked; });
        button.addEventListener('click', async () => {
          try {
            if (rule.role === 'target') {
              // Chrome requires permissions.request to be called directly
              // within a user gesture before any asynchronous operation.
              const website = new URL(rule.policy.siteOrigin);
              if(website.protocol==='http:' && !window.confirm(
                '确认接收来自 HTTP 网站的会话？此站点本身并未加密，Cookie 和登录数据可能在访问网站时被窃取。'))return;
              const origins=rule.policy.allCookies?cookieAccessOrigins(rule.policy.siteOrigin)
                :[website.protocol+'//'+website.hostname+'/*'];
              const granted = await chrome.permissions.request({origins});
              if (!granted) { status('未授权目标站点。'); return; }
              await ask({ type: 'ACCEPT_RULE', ruleId: rule.id, confirmed: true, pairingCode: rule.code });
            } else {
              await ask({ type: 'CONFIRM_RULE', ruleId: rule.id, confirmed: true, pairingCode: rule.code });
            }
            status('配对授权已更新。只允许已激活的配对同步。');
            await refreshPairing();
          } catch (error) { failure(error); }
        });
        card.append(button);
      }
    }
    if(rule.status==='active' && rule.valid){
      if(rule.network?.status==='offered' && rule.role==='target'){
        card.append(textNode('p','来源设备申请：访问 '+rule.network.host+
          ' 时经由 Agent '+rule.network.exitDeviceId+' 出口。'));
        const approve=document.createElement('button');
        approve.textContent='接受网络绑定邀请';
        approve.disabled=!rule.network.matchingHost;
        approve.addEventListener('click',async()=>{
          if(!window.confirm('此网站将通过来源设备出口访问；出口离线时会阻断连接。确定启用？'))return;
          try{
            await ask({type:'NETWORK_ACCEPT',ruleId:rule.id,confirmed:true});
            status('网络绑定已授权；该网站将通过选择的 Agent 出口访问。');
            await refreshPairing();
          }catch(error){failure(error);}
        });
        card.append(approve);
      }
      if(rule.network?.status==='offered'){
        card.append(textNode('p',rule.role==='source'
          ? '网络绑定邀请已发送，等待接收端确认；可取消后更换出口。'
          : '尚未接受该网络邀请；可以取消，取消后来源端可重新邀请。'));
      }
      if(rule.role==='source' && (!rule.network ||
         rule.network.status==='none'||rule.network.status==='revoked')){
        const action=document.createElement('button');
        action.textContent=rule.network?.status==='revoked'?'重新发起网络绑定邀请':'绑定已授权网络出口';
        action.title='显示该身份下所有已授权且在线的 Agent proxy.exit 出口，包括远程出口';
        action.addEventListener('click',async()=>{
          try{
            const exits=(await ask({type:'NETWORK_EXITS'})).exits||[];
            if(!exits.length)throw new Error(
              '当前没有可用网络出口。请检查：① Server 已启用 Browser Sync 和 TLS/TCP 中继；' +
              '② 已授权 proxy.exit 的 Agent 在线；' +
              '③ Agent 与浏览器属于同一身份。');
            const select=document.createElement('select');
            for(const exit of exits){
              const opt=document.createElement('option');
              opt.value=exit.id;
              opt.textContent=(exit.name||'Agent')+' · '+exit.id;
              select.append(opt);
            }
            const approve=document.createElement('button');
            approve.textContent='发送网络绑定邀请';
            approve.addEventListener('click',async()=>{
              try{
                await ask({type:'NETWORK_OFFER',ruleId:rule.id,exitDeviceId:select.value});
                status('网络绑定已提出，等待 B 端独立确认。');
                await refreshPairing();
              }catch(error){failure(error);}
            });
            card.append(select,approve);
            action.disabled=true;
          }catch(error){failure(error);}
        });
        card.append(action);
      }
      if(rule.network?.status==='active')
        card.append(textNode('p','网络：'+rule.network.host+' → '+rule.network.exitDeviceId));
      if(['offered','active'].includes(rule.network?.status)){
        const isOffered=rule.network.status==='offered';
        const revoke=document.createElement('button');
        revoke.className='secondary-button';
        revoke.textContent=isOffered?'取消网络绑定邀请':'撤销网络绑定';
        revoke.addEventListener('click',async()=>{
          if(!window.confirm(isOffered
            ? '取消此次网络绑定邀请？接收端将无法批准已取消的邀请，来源端可重新选择出口发送。'
            : '撤销后将停止使用当前 Agent 出口，可能恢复本机网络；已同步的登录状态不会自动清除。继续？'))return;
          try{
            await ask({type:'NETWORK_REVOKE',ruleId:rule.id});
            status(isOffered?'邀请已取消，可以重新发起网络绑定。':'网络绑定已撤销，可以重新选择出口。');
            await refreshPairing();
          }catch(error){failure(error);}
        });
        card.append(revoke);
      }
    }
    if (rule.status==='active' && rule.valid && rule.role==='target'){
      const current=rule.localNetworkMode==='local_agent'?'本机 Agent':rule.localNetworkMode==='source_agent'?'已授权远程 Agent':'未启用';
      card.append(textNode('p','当前站点网络出口：'+current));
      const local=document.createElement('button');
      local.textContent='改用本机 Agent 代理';
      local.disabled=rule.localNetworkMode==='local_agent';
      local.addEventListener('click',()=>{
        local.disabled=true;
        const help=textNode('p','此网站使用当前设备的 Agent 分流及出口。');
        const port=document.createElement('input');
        port.type='number';port.min='1024';port.max='65535';port.value='21291';
        port.placeholder='本机监听端口';
        port.setAttribute('aria-label','本机 Agent 监听端口');
        const confirm=document.createElement('button');confirm.textContent='确认绑定本机 Agent';
        confirm.addEventListener('click',async()=>{
          if(!window.confirm('此网站将改用当前设备 Agent 出口；匹配 DIRECT 的规则会被阻断以防止泄漏。确定切换？'))return;
          try{
            await ask({type:'NETWORK_LOCAL_ENABLE',ruleId:rule.id,
              port:Number(port.value),confirmed:true});
            status('已切换至本机 Agent。');
            await refreshPairing();
          }catch(error){failure(error);}
        });
        card.append(help,port,confirm);
      });
      card.append(local);
      if(rule.network?.status==='active'&&rule.network.matchingHost&&rule.localNetworkMode!=='source_agent'){
        const useSource=document.createElement('button');
        useSource.textContent='切换到已授权网络出口';
        useSource.addEventListener('click',async()=>{
          try{
            await ask({type:'NETWORK_USE_SOURCE',ruleId:rule.id});
            status('已切换到已授权网络出口');
            await refreshPairing();
          }catch(error){failure(error);}
        });
        card.append(useSource);
      }
      if(rule.localNetworkMode==='local_agent'){
        const stop=document.createElement('button');
        stop.textContent='停用本机站点代理';
        stop.addEventListener('click',async()=>{
          if(!window.confirm('停用后此网站可能使用本机网络直连；已同步的登录状态不会自动清除。确定？'))return;
          try{
            await ask({type:'NETWORK_LOCAL_DISABLE',ruleId:rule.id});
            await refreshPairing();
          }catch(error){failure(error);}
        });
        card.append(stop);
      }
    }
    if (rule.status === 'active' && rule.valid) {
      // Options are parameters of the NEXT explicit sync, not separate
      // actions or permanent account overwrite grants.
      let openAfter=null,overwriteOnce=null;
      if(rule.role==='target'){
        const options=document.createElement('div');
        options.className='sync-preferences';
        const openLabel=document.createElement('label');
        openAfter=document.createElement('input');
        openAfter.type='checkbox';
        openLabel.append(openAfter,textNode('span','同步成功后打开页面'));
        const overwriteLabel=document.createElement('label');
        overwriteOnce=document.createElement('input');
        overwriteOnce.type='checkbox';
        overwriteLabel.append(overwriteOnce,textNode('span','允许本次覆盖现有登录数据'));
        options.append(openLabel,overwriteLabel);
        card.append(options);
        if(rule.lastTransfer?.state==='PARTIAL'){
          card.append(textNode('p','上次恢复不完整，请确认站点登录状态后手动恢复此规则。','error'));
          const resume=document.createElement('button');
          resume.textContent='我已检查登录状态，恢复此规则';
          resume.addEventListener('click',async()=>{
            if(!window.confirm('确认已检查目标登录状态且没有混合账号？'))return;
            try{
              await ask({type:'RESUME_PARTIAL_RESTORE',ruleId:rule.id,confirmed:true});
              await refreshPairing();
            }catch(error){failure(error);}
          });
          card.append(resume);
        }
      }
      const sync=document.createElement('button');
      sync.textContent=rule.role==='source'?'立即发送加密登录状态':'请求同步';
      sync.addEventListener('click',async()=>{
        let granted=false;
        sync.disabled=true;
        try{
          if(rule.role==='source'){
            const answer=await ask({type:'SEND_SESSION',ruleId:rule.id});
            status(answer.state==='RELAYED'?'密文已转发，等待接收端应用。':'正在发送会话状态。');
          }else{
            const overwrite=overwriteOnce.checked;
            const shouldOpen=openAfter.checked;
            if(overwrite&&!window.confirm(
              '本次同步可能覆盖目标端已选范围内的登录数据并切换账号。仅允许本次同步覆盖，确认？'))return;
            let requestId='';
            if(overwrite){
              const result=await ask({type:'ALLOW_OVERWRITE',ruleId:rule.id,allowed:true});
              if(!result.transferRequestId)throw new Error('缺少一次性覆盖授权标识');
              requestId=result.transferRequestId;
              granted=true;
            }
            const action=shouldOpen?'SYNC_THEN_OPEN':'REQUEST_SESSION';
            try{
              await ask({type:action,ruleId:rule.id,
                ...(requestId?{transferRequestId:requestId}:{})});
              status(shouldOpen?'已请求同步，成功应用后才会打开页面。':'已请求同步，等待来源端传输。');
            }catch(error){
              if(granted)await ask({type:'ALLOW_OVERWRITE',ruleId:rule.id,allowed:false}).catch(()=>{});
              throw error;
            }finally{
              // Every overwrite consent applies to at most this one request.
              overwriteOnce.checked=false;
            }
          }
        }catch(error){failure(error);}
        finally{sync.disabled=false;}
      });
      card.append(sync);
    }
    const revoke = document.createElement('button');
    revoke.textContent = '撤销配对';
    revoke.addEventListener('click', async () => {
      try {
        if (!window.confirm('确定撤销此配对规则？此操作不会退出网站已登录的设备。')) return;
        await ask({ type: 'REVOKE_RULE', ruleId: rule.id });
        status('规则已撤销，不再允许后续同步。');
        await refreshPairing();
      } catch (error) { failure(error); }
    });
    card.append(revoke);
    parent.append(card);
  }
}

$('refresh-pairing').addEventListener('click', async () => {
  try { await refreshPairing(); status('已更新配对设备和邀请。'); }
  catch (error) { failure(error); }
});

$('offer-rule').addEventListener('click', async () => {
  try {
    const siteOrigin = $('pair-site').value;
    const targetID = $('target').value;
    if (!targetID || !siteOrigin) throw new Error('请先选择网站与接收设备');
    if(siteOrigin.startsWith('http://') && !window.confirm(
      '即将为 HTTP 网站创建会话配对。虽然同步数据端到端加密，但站点访问本身仍可能泄露登录凭据。继续？'))return;
    const dataTypes={allCookies:$('sync-cookies').checked,
      localStorage:$('sync-local').checked,
      sessionStorage:$('sync-session').checked,indexedDB:$('sync-indexeddb').checked};
    if(!Object.values(dataTypes).some(Boolean))
      throw new Error('至少勾选一种同步数据类型');
    const result=await ask({type:'CREATE_RULE',siteOrigin,targetID,dataTypes});
    status('已创建加密邀请 ' + result.ruleId.slice(0, 8) + '，请双方核对配对校验码。');
    await refreshPairing();
  } catch (error) { failure(error); }
});

// Task-first navigation: the current page style stays intact, while only the
// selected panel is displayed. Deep links and the extension popup still work.
export function activateSettingsSection(sectionId){
  const panels=[...document.querySelectorAll('.settings-main > .settings-section')];
  const selected=panels.some(panel=>panel.id===sectionId)?sectionId:'server-section';
  for(const panel of panels)panel.hidden=panel.id!==selected;
  for(const link of document.querySelectorAll('.settings-nav a[href^="#"]')){
    const active=link.getAttribute('href')==='#'+selected;
    link.classList.toggle('active',active);
    if(active)link.setAttribute('aria-current','page');
    else link.removeAttribute('aria-current');
  }
  document.querySelector('.settings-main')?.scrollIntoView?.({block:'start'});
  return selected;
}
document.querySelectorAll('.settings-nav a[href^="#"]').forEach(link=>{
  link.addEventListener('click',event=>{
    event.preventDefault();
    const id=link.getAttribute('href').slice(1);
    if(window.location.hash!=='#'+id)window.location.hash=id;
    else activateSettingsSection(id);
  });
});
window.addEventListener('hashchange',()=>activateSettingsSection(window.location.hash.slice(1)));
activateSettingsSection(window.location.hash.slice(1));

// The MV3 background checks Server approval using a persisted one-minute
// alarm. This lightweight UI refresh only reads Chrome's local connection
// state; it never polls an unapproved Server or resubmits enrollment.
let previousConnected=false;
let transferRefreshTimer=null;
async function updateConnectionState(){
  const result=await chrome.runtime.sendMessage({type:'GET_STATUS'});
  if(!result?.ok)return;
  $('server-stage').textContent=result.connected?'设备认证已连接':
    result.pendingApproval?'等待管理员审批，批准后自动连接':
    result.settings?.serverOrigin?'尚未连接 Server':'尚未配置 Server';
  if(result.connected&&!previousConnected){
    if($('server-stage').dataset.waitingApproval==='true')
      status('设备已获管理员批准，扩展已自动连接服务端。');
    $('server-stage').dataset.waitingApproval='false';
    await refreshPairing().catch(()=>{});
  }
  if(result.pendingApproval)$('server-stage').dataset.waitingApproval='true';
  previousConnected=!!result.connected;
}
load().then(()=>{
  updateConnectionState().catch(()=>{});
  // Chrome's authenticated WSS connection and pending-approval lifecycle
  // trigger sanitized storage invalidations. Fetch authoritative GET_STATUS
  // only on events, focus, or a slow fallback (not an 8-second UI poll).
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area==='local'&&(changes.browserSyncConnectionNotice||
       changes.browserSyncPendingEnrollment))
      updateConnectionState().catch(()=>{});
    if(area==='local'&&(changes.browserSyncTransferStatus||changes.browserSyncRestorePaused)){
      clearTimeout(transferRefreshTimer);
      transferRefreshTimer=setTimeout(async()=>{
        // A local result must not turn every SENDING/RELAYED/ACK transition
        // into Server list queries and exhaust the control-frame budget.
        try{
          const stored=await chrome.storage.local.get(TRANSFER_STATUS_KEYS);
          for(const rule of cachedRules)rule.lastTransfer=ruleTransferStatus(rule.id,stored);
          renderRules(cachedRules,cachedPeers);
        }catch{ /* a manual refresh can recover a closed page */ }
      },100);
    }
  });
  document.addEventListener('visibilitychange',()=>{
    if(document.visibilityState==='visible')updateConnectionState().catch(()=>{});
  });
  window.addEventListener('focus',()=>updateConnectionState().catch(()=>{}));
  setInterval(()=>{if(document.visibilityState==='visible')
    updateConnectionState().catch(()=>{});},60000);
}).catch(failure);

